from .interest import cd_interest, si_interest, total_amount

__all__ = ["simple_interest", "compound_interest", "total_amount"]