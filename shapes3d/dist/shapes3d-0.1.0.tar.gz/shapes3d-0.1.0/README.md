USE 
pip install shapes3d