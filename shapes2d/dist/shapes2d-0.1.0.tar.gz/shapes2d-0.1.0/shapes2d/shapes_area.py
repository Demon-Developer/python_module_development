def area_of_triangle(base,height):
    total = (1/2)*base*height
    return total
def area_of_rectangle(length,breath):
    total=length*breath
    return total
def area_of_square(side):
    total= side *side 
    return total
def area_of_circle(radius):
    total= 3.14159265359 * (radius* radius)
    return total
def area_of_trapezoid(length,breath,height):
    total = (1/2)*(length + breath) *height
    return total
def area_of_parallelogram(breath,height):
    total= breath*height
    return total
